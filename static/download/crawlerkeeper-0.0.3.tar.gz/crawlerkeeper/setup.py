#!/usr/bin/env python
#from distutils.core import setup
#from distutils.core import setup
from setuptools import setup, find_packages

setup(
    name="crawlerkeeper",
    version="0.0.3",
    description="A library for manager crawler.",
    author="Chenxi Dong",
    author_email="dongchenxi@xiaomi.com",
    url="",
    packages = find_packages()
    #packages=["crawlerkeeper"],
    #package_dir={"crawlerkeeper":"crawlerkeeper"} ,
    #package_data={"crawlerkeeper":["*.*","client/*","common/*","conf/*","core/*","logger/*","notify/*","rpc/*","server/*","service/*","settings/*"]}
)




